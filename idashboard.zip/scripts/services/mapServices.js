var mapServices = angular.module('mapServices',['ngResource']);

mapServices.factory('mapManager',['$http','olData','olHelper','shared',function($http,olData,olHelper,shared){
    'use strict';

}]);

mapServices.factory('shared',function(){
    var shared = {facility:0};
    return shared;

});


/* global angular */

'use strict';

/* Controllers */
var idashboardControllers = angular.module('idashboardControllers', ['mainController','dashboardController']);


/* global angular */

'use strict';

/* Services */

var idashboardServices = angular.module('idashboardServices', [ 'mainServices','mapServices','chartServices','tableServices' ]);

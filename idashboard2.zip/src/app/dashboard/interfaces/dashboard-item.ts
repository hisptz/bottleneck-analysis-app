export interface DashboardItem {
    id: string;
    dashboardItems: Array<any>;
}

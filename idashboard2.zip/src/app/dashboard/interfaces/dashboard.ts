export interface Dashboard {
    id: string;
    name: string;
    dashboardItems: Array<any>
}

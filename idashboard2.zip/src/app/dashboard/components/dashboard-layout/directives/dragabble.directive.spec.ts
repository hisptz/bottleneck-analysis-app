import { DragabbleDirective } from './dragabble.directive';

describe('DragabbleDirective', () => {
  it('should create an instance', () => {
    const directive = new DragabbleDirective();
    expect(directive).toBeTruthy();
  });
});

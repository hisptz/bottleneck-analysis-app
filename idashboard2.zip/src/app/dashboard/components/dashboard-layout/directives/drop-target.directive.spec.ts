import { DropTargetDirective } from './drop-target.directive';

describe('DropTargetDirective', () => {
  it('should create an instance', () => {
    const directive = new DropTargetDirective();
    expect(directive).toBeTruthy();
  });
});

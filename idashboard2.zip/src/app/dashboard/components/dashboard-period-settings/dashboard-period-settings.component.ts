import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-period-settings',
  templateUrl: './dashboard-period-settings.component.html',
  styleUrls: ['./dashboard-period-settings.component.css']
})
export class DashboardPeriodSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-orgunit-settings',
  templateUrl: './dashboard-orgunit-settings.component.html',
  styleUrls: ['./dashboard-orgunit-settings.component.css']
})
export class DashboardOrgunitSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { AutosizeDirective } from './autosize.directive';

describe('AutosizeDirective', () => {
  it('should create an instance', () => {
    const directive = new AutosizeDirective();
    expect(directive).toBeTruthy();
  });
});

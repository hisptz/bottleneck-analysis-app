import { ContextMenuDirective } from './context-menu.directive';

describe('ContextMenuDirective', () => {
  it('should create an instance', () => {
    const directive = new ContextMenuDirective();
    expect(directive).toBeTruthy();
  });
});
